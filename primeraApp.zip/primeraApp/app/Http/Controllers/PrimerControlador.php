<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PrimerControlador extends Controller
{
    
    function ruta1() {
        return '<h1>resultado ruta 1</h1>';
    }
}