@extends('base')

@section('content')
<h1>
    El parámetro que he obtenido es: {{ $id }}
</h1>
@endsection