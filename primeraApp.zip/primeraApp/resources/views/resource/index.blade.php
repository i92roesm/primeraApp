@extends('base')

@section('content')
<h1>{{ $enterprise }}</h1>
<table class="table table-striped">
    <thead>
        <tr>
            <th scope="col"># id</th>
            <th scope="col">name</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($resources as $resource)
            <tr>
                <td>
                    {{ $resource['id'] }}
                </td>
                <td>
                    {{ $resource['name'] }}
                </td>
                <td>
                    <a href="{{ url('resource/' . $resource['id'] . '/edit') }}">edit</a>
                    <a href="{{ route('resource.edit', $resource['id']) }}">edit</a>
                    <a href="{{ action([App\Http\Controllers\ResourceController::class, 'edit'], $resource['id']) }}">edit</a>
                </td>
                <td>
                    <a href="">delete</a>
                </td>
            </tr>
        @endforeach
    </tbody>
</table>
<a href="{{ url('resource/create') }}" class="btn btn-primary btn-lg" type="button">Add new resource</a>
@endsection