<?php $__env->startSection('content'); ?>
<h1><?php echo e($enterprise); ?></h1>
<table class="table table-striped">
    <thead>
        <tr>
            <th scope="col"># id</th>
            <th scope="col">name</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($resource['id']); ?>

                </td>
                <td>
                    <?php echo e($resource['name']); ?>

                </td>
                <td>
                    <a href="<?php echo e(url('resource/' . $resource['id'] . '/edit')); ?>">edit</a>
                    <a href="<?php echo e(route('resource.edit', $resource['id'])); ?>">edit</a>
                    <a href="<?php echo e(action([App\Http\Controllers\ResourceController::class, 'edit'], $resource['id'])); ?>">edit</a>
                </td>
                <td>
                    <a href="">delete</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<a href="<?php echo e(url('resource/create')); ?>" class="btn btn-primary btn-lg" type="button">Add new resource</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/primeraApp/resources/views/resource/index.blade.php ENDPATH**/ ?>