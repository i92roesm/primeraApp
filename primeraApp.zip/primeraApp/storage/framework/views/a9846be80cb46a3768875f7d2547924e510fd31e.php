<?php $__env->startSection('cuerpo'); ?>
    ##parent-placeholder-74247235940cb22c418c46a45ffa6432b6ce8328##
    <p>This is the new main content. <?php echo e($dato1); ?> <?php echo e($dato2); ?> <?php echo $dato3 ?? 'no está el dato 3'; ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla1.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/primeraApp/resources/views/plantilla1/subplantilla/secondmain.blade.php ENDPATH**/ ?>