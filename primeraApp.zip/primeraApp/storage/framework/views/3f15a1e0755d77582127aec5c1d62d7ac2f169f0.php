<?php $__env->startSection('content'); ?>
<h1>
    El parámetro que he obtenido es: <?php echo e($id); ?>

</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/primeraApp/resources/views/base/parametro.blade.php ENDPATH**/ ?>